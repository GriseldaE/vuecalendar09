<script>
export default {
  data() {
    return {
      dias: ['Domingo','Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Viernes'],
      calendario: [],
      mes: '',
      anualidad: 2023,
      eventCalendar: [
        { titulo: 'fiesta', date: '2023-11-15', descripcion: 'Cumpleaños de mamá' },
        { titulo: 'reunion', date: '2023-10-18', descripcion: 'Reunion del proyecto' },
          ],
    };
  },
  mounted() {
    this.calendariodefechas();
  },
  methods: {
    calendariodefechas() {
      const currentDate = new Date(this.anualidad, this.mesindex(this.mes), 1);
      this.mes = this.mesesname(currentDate.getMonth());
      this.anualidad = currentDate.getFullYear();

      const primerdiames = new Date(this.anualidad, currentDate.getMonth(), 1);
      const ultidiames = new Date(this.anualidad, currentDate.getMonth() + 1, 0);

      const diasmes = ultidiames.getDate();
      const diasprimsemana = primerdiames.getDay();

      let date = 1;
      this.calendarioa = [];

      for (let i = 0; i < 6; i++) {
        let semana = [];
        for (let j = 0; j < 7; j++) {
          if ((i === 0 && j < diasprimsemana) || date > diasmes) {
            semana.push({ dia: '', date: '', eventCalendar: [] });
          } else {
            const dia = new Date(this.anualidad, currentDate.getMonth(), date);
            const eventoseneldia = this.getEventsOnDay(dia);
            semana.push({ dia: date, date: dia.toISOString().split('T')[0], eventCalendar: eventoseneldia });
            date++;
          }
        }
        this.calendarioa.push(semana);
      }
    },
    mesesname(monthIndex) {
      const mesess = [
        'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
        'Julio', 'Augosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  
      ];
      return mesess[monthIndex];
    },
    mesindex(mesessname) {
      const mesess = [
      'Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
        'Julio', 'Augosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'
  
      ];
      return mesess.indexOf(mesessname);
    },
    getEventsOnDay(dia) {
      return this.eventCalendar.filter(evento => {
        const eventDate = new Date(evento.date);
        return eventDate.toISOString().split('T')[0] === dia.toISOString().split('T')[0];
      });
    },
    Anterior() {
      this.anualidad = this.mes === 'Enero' ? this.anualidad - 1 : this.anualidad;
      this.mes = this.mes === 'Enero' ? 'Diciembre' : this.mesesname(this.mesindex(this.mes) - 1);
      this.calendariodefechas();
    },
    Siguiente() {
      this.anualidad = this.mes === 'Diciembre' ? this.anualidad + 1 : this.anualidad;
      this.mes = this.mes === 'Diciembre' ? 'Enero' : this.mesesname(this.mesindex(this.mes) + 1);
      this.calendariodefechas();
    },
  },
};
</script>
<template>
  <div>
    <div>
      <button @click="Anterior">Anterior</button>
      <h1>{{ mes }} {{ anualidad }}</h1>
      <button @click="Siguiente">Siguiente</button>
    </div>
    <table>
      <thead>
        <tr>
          <th v-for="dia in dias" :key="dia">{{ dia }}</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(semana, index) in calendarioa" :key="index">
          <td v-for="dia in semana" :key="dia.date">
            {{ dia.dia }}
            <ul v-if="dia.eventCalendar.length > 0">
              <li v-for="evento in dia.eventCalendar" :key="evento.titulo">
                {{ evento.titulo }} - {{ evento.descripcion }}
              </li>
            </ul>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>


